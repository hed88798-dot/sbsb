# Code C Python Inventory Review Request

- Bundle: `code-c-python-inventory-review-ce5590e262a5-a809279fe384ac9b`
- Code C HEAD: `ce5590e262a522e1ebff6039c6acae7423a3e778`
- Semantics: `BATCH_CONTAINER_ONLY`
- Inventory requests: 4 (Linux/Windows runtime and worker-build)
- Toolchain evidence requests: 2 (Linux and Windows)
- Approval owner: Code F
- Python Inventory Gate: `BLOCKED_PENDING_CODE_F_APPROVAL`
- Worker, Native, License, Stage B, SigLIP and Index gates: `BLOCKED_NOT_RERUN`

Each inventory/role requires an independent approval decision. Acceptance of this bundle does not approve any contained inventory.
